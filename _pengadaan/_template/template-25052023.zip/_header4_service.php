                                            <div class="row">
                                                <div class="col-xs-12 col-sm-6">
                                                    <div class="form-group">
                                                        <label class="col-sm-6 control-label no-padding-right"> KM Sekarang :</label>									
                                                        <div class="col-sm-6">
                                                            <input type="text" class="form-control" 
                                                            id="txtkm_skr" name="txtkm_skr" required autocomplete="off" />
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-6 control-label no-padding-right"> Status :</label>									
                                                        <div class="col-sm-6">
                                                            <input type="text" class="form-control" 
                                                            id="txtkm_skr" name="txtkm_skr" required autocomplete="off" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6">
                                                    <div class="form-group">
                                                        <label class="col-sm-6 control-label no-padding-right"> KM Berikut :</label>									
                                                        <div class="col-sm-6">
                                                            <input type="text" class="col-xs-10 col-sm-12" 
                                                            id="txtkm_berikut" name="txtkm_berikut" disabled />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-12">
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label no-padding-right"> Keterangan<br>/Keluhan :</label>									
                                                        <div class="col-sm-9">
                                                            <textarea class="col-xs-10 col-sm-12" id="txtnote" name="txtnote" rows="3"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>