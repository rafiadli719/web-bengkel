<div class="col-xs-12 col-sm-12">
    <div class="widget-box">
        <div class="widget-body">
            <div class="widget-main">
            
                                            <div class="row">
                                                <div class="col-xs-8 col-sm-3">
                                                    <a href="pmby_hutang_add.php">
                                                    <button class="btn btn-primary btn-block" type="button">
                                                        Input 
                                                    </button>  
                                                    </a>
                                                </div>
                                                <div class="col-xs-8 col-sm-3">
                                                    <button class="btn disabled btn-primary btn-block" type="button">
                                                        Batal
                                                    </button>
                                                </div>
                                                <div class="col-xs-8 col-sm-3">
                                                    <a target="_blank"  href="pembayaran_hutang_struk.php?snotrx=<?php echo $nobyr; ?>">                                                
                                                        <button class="btn btn-primary btn-block" type="button">
                                                            Cetak
                                                        </button>            
                                                    </a>                                    
                                                </div>
                                                <div class="col-xs-8 col-sm-3">
                                                    <a href="pmby_hutang.php">
                                                    <button class="btn btn-primary btn-block" type="button">
                                                        Tutup
                                                    </button>  
                                                    </a>
                                                </div>                                                
                                            </div>
            
            </div>
        </div>
    </div>
</div>