						<div class="row">
							<div class="col-xs-12 col-sm-9">
								<div class="widget-box">
									<div class="widget-body">
										<div class="widget-main">	
                                        
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-4">
                                                    <div class="form-group">
                                                        <label class="col-sm-4 control-label no-padding-right" for="txtnopesanan"> No :</label>									
                                                        <div class="col-sm-8">
                                                            <input type="text" class="form-control" value="<?php echo $LastID; ?>" disabled />
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-4 control-label no-padding-right" for="form-field-1"> Tanggal :</label>									
                                                        <div class="col-sm-8">
                                                            <div class="input-group">
                                                                <input class="form-control date-picker" id="id-date-picker-1" name="id-date-picker-1" type="text" autocomplete="off" required data-date-format="dd/mm/yyyy" />
                                                                <span class="input-group-addon">
                                                                    <i class="fa fa-calendar bigger-110"></i>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-8">
                                                    <div class="form-group">
                                                        <label class="col-sm-2 control-label no-padding-right" for="txtnopesanan"> Pelanggan :</label>									
                                                        <div class="col-sm-10">
                                                            <input type="text" class="form-control" value="<?php echo $kode_pelanggan; ?>" disabled />
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-2 control-label no-padding-right" for="form-field-1"> Nama :</label>									
                                                        <div class="col-sm-10">
                                                            <input type="text" class="form-control" value="<?php echo $namapelanggan; ?>" disabled />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

							<div class="col-xs-12 col-sm-3">
								<div class="widget-box">
									<div class="widget-body">
										<div class="widget-main">	
                                        
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-12">
                                                    <div class="form-group">
                                                        <label class="col-sm-4 control-label no-padding-right" for="txtnopesanan"> User :</label>									
                                                        <div class="col-sm-8">
                                                            <input type="text" class="form-control" value="<?php echo $_nama; ?>" disabled />
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-4 control-label no-padding-right" for="txtnopesanan"> Tgl / Jam :</label>									
                                                        <div class="col-sm-8">
                                                            <input type="text" class="form-control" value="<?php echo $tanggal_skr; ?>" disabled />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>