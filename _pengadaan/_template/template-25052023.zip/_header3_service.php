						<div class="row">
							<div class="col-xs-12 col-sm-7">
								<div class="widget-box">
									<div class="widget-body">
										<div class="widget-main">
                                        
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
							<div class="col-xs-12 col-sm-5">
								<div class="widget-box">
									<div class="widget-body">
										<div class="widget-main">
                                        
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>