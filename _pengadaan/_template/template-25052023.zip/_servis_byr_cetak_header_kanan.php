
											<div class="widget-box">
												<div class="widget-body">
													<div class="widget-main">
                                                    
                                                        <div class="row">
															<div class="col-xs-8 col-sm-6">
                                                                <label>No. Service :</label>
                                                                <div class="row">
                                                                    <div class="col-xs-8 col-sm-12">
                                                                        <input type="text" class="form-control" 
                                                                        value="<?php echo $no_service; ?>" readonly="true" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="space space-8"></div>                                                                                                                
                                                        <div class="row">
															<div class="col-xs-8 col-sm-6">
                                                                <label>Km Sekarang :</label>
                                                                <div class="row">
                                                                    <div class="col-xs-8 col-sm-12">
                                                                        <input type="text" class="form-control" 
                                                                        id="txtkm_skr" name="txtkm_skr" 
                                                                        value="<?php echo $km_skr; ?>" 
                                                                        readonly="true" />
                                                                    </div>
                                                                </div>
                                                            </div>
															<div class="col-xs-8 col-sm-6">
                                                                <label for="id-date-picker-1">Km Berikut :</label>
                                                                <div class="row">
                                                                    <div class="col-xs-8 col-sm-12">
                                                                        <input type="text" class="form-control" 
                                                                        id="txtkm_next" name="txtkm_next" 
                                                                        value="<?php echo $km_berikut; ?>" readonly="true" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="space space-8"></div>                                                                                                                 
															<div class="col-xs-8 col-sm-12">
                                                                <h4 class="header green">Keluhan</h4>
                                                            </div>
															<div class="col-xs-8 col-sm-12">
                                                                <table class="table table-bordered">
                                                                    <thead>
                                                                        <tr>
                                                                            <td class="center" width="5%">No</td>
                                                                            <td width="95%">Keluhan</td>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php 
                                                                            $no = 0 ;
                                                                            $sql = mysqli_query($koneksi,"SELECT 
                                                                                                            keluhan, id 
                                                                                                            FROM 
                                                                                                            tbservis_keluhan 
                                                                                                            WHERE 
                                                                                                            no_service='$no_service'");
                                                                            while ($tampil = mysqli_fetch_array($sql)) {
                                                                                $no++;
                                                                        ?>
                                                                        <tr>
                                                                            <td class="center"><?php echo $no ?></td>
                                                                            <td>
                                                                                <?php echo $tampil['keluhan']?>
                                                                            </td>														
                                                                        </tr>
                                                                    <?php
                                                                        }
                                                                    ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>

															<div class="col-xs-8 col-sm-12">
                                                                <h4 class="header green">Item Pengerjaan</h4>
                                                            </div>
															<div class="col-xs-8 col-sm-12">
                                                                <table class="table table-bordered">
                                                                    <thead>
                                                                        <tr>
                                                                            <td class="center" width="5%">No</td>
                                                                            <td width="60%">Item Pengerjaan</td>
                                                                            <td width="35%">Mekanik</td>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php 
                                                                            $no = 0 ;
                                                                            $sql = mysqli_query($koneksi,"SELECT 
                                                                                                            item_pengerjaan, kd_mekanik, id 
                                                                                                            FROM 
                                                                                                            tbservis_pengerjaan 
                                                                                                            WHERE 
                                                                                                            no_service='$no_service'");
                                                                            while ($tampil = mysqli_fetch_array($sql)) {
                                                                                $no++;
                                                                                $kd_mekanik=$tampil['kd_mekanik'];
                                                                                $cari_kd=mysqli_query($koneksi,"SELECT 
                                                                                                                nama 
                                                                                                                FROM tblmekanik 
                                                                                                                WHERE nomekanik='$kd_mekanik'");			
                                                                                $tm_cari=mysqli_fetch_array($cari_kd);
                                                                                $nama_mekanik=$tm_cari['nama'];				        
                                                                        ?>
                                                                        <tr>
                                                                            <td class="center"><?php echo $no ?></td>
                                                                            <td>
                                                                                <?php echo $tampil['item_pengerjaan']?>
                                                                            </td>														
                                                                            <td>
                                                                                <?php echo $nama_mekanik; ?>
                                                                            </td>														
                                                                        </tr>
                                                                    <?php
                                                                        }
                                                                    ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                       </div>

													</div>
												</div>
											</div>        